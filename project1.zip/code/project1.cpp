#include <stdio.h>
#include <time.h>
#include <stdlib.h>
//define the max size of the matrix is 100, but you can change it if you want
#define maxSize 100
//this function is to solve the problem

//time complexity is O(N^6)
int MaxSubMatrixSum_Algorithm1(int a[maxSize][maxSize], int N);
//time complexity is O(N^4)
int MaxSubMatrixSum_Algorithm2(int a[maxSize][maxSize], int N);
//this is the function to solve the maximum subsequence sum of array 
int MaxSubSequenceSum(int A[], int N);

//this variables count the ticks and the time
clock_t start, stop;
double duration; /*records the run time (seconds) of a function*/

int main()
{
    int N, m, n, i, j, k, l;
    int cnt=0;
    int maxSum, choice;
    srand(time(NULL));

    /***************
	*STEP 1 : get N*
	***************/
    printf("Please input size of matrix:");
    scanf("%d", &N);
    
    /**************************
	*STEP 2 : build matrix    *
	**************************/
    int a[maxSize][maxSize];
    
    for(i=0; i<N; i++){
        for(j=0; j<N; j++){
            a[i][j] = rand() % 21 -10;
            cnt++;
            printf("%d ", a[i][j]);
        }
        printf("\n");
    }
    printf("\nThe number of the elements of the matrix is:%d\n", cnt);
    
    /****************************************
	*STEP 3 : excute our different algorithm*
	****************************************/
    printf("Please choose the algorithm: 1 or 2\n");
    scanf("%d", &choice);
    if(choice == 1){
        
        /*clock() returns the amount of processor time (ticks) that has elapsed since the program begun running*/
        start = clock(); /*records the ticks at the beginning of the function call*/

        /*you can change the iteration times, which is 1000 now*/
        for(i=0; i<1000; i++){
            maxSum = MaxSubMatrixSum_Algorithm1(a, N);
        }
        
        stop = clock(); /*records the ticks at the end of the function call*/
        duration = ((double)(stop-start)) / CLK_TCK; /*CLK_TCK is a built-in constant and it equals to tick per second*/
        printf("\n//ticks = %d  duration = %lf**//\n", stop-start, duration);

    }else if(choice == 2){
    
        /*clock() returns the amount of processor time (ticks) that has elapsed since the program begun running*/
        start = clock(); /*records the ticks at the beginning of the function call*/

        /*you can change the iteration times, which is 1000 now*/
        for(i=0; i<1000; i++){
            maxSum = MaxSubMatrixSum_Algorithm2(a, N);
        }
        
        stop = clock(); /*records the ticks at the end of the function call*/
        duration = ((double)(stop-start)) / CLK_TCK; /*CLK_TCK is a built-in constant and it equals to tick per second*/
        printf("\n//ticks = %d  duration = %lf**//\n", stop-start, duration);
    }else{
        printf("Invalid choice");
    }
    printf("max submatrix sum = %d\n", maxSum);

    return 0;
}

/********************************************************************
*Algorithm 1: O(N^6)                                                *
*parameters: a[][] is matrix    N is the size of matrix             *    
*Main idea:                                                         *
*   1.use 4 for loops to trverse every matrix.                      *
*   2.calculate the sum of each submatrix.                          *
*   3.find maximum results.                                         *
********************************************************************/
int MaxSubMatrixSum_Algorithm1(int a[maxSize][maxSize], int N)
{
    int m, n, i, j, k, l;
    int thisSum, maxSum;

    maxSum = 0;
    //form row i to row m
    //from column j to column n
    //through i j m n, we can express a submatrix:
    //The upper-left element of submatrix is a[i][j]
    //The lower-right element of submatrix is a[m][n]
    for(i=0; i<N; i++){
        for(m=i; m<N; m++){
            for(j=0; j<N; j++){
                for(n=j; n<N; n++){
                    
                    //Calculate the sum of each submatrix
                    thisSum = 0;
                    for(k=i; k<=m; k++){
                        for(l=j; l<=n; l++){
                            thisSum = thisSum + a[k][l];
                        }
                    }
                    //if thisSum is bigger than maxSum, update maxSum
                    if(thisSum > maxSum){
                        maxSum = thisSum;
                    }
                }
            }
        }
    }
    
    return maxSum;
}

/********************************************************************
*Algorithm 2: O(N^4)                                                *
*parameters: a[][] is matrix    N is the size of matrix             *    
*Main idea:                                                         *
*   1.use 2 for loops to express all possible rows combination.     *
*   2.calculate the sum of every row form i to m.                   *
*   3.find max subsequence sum of b[].
*   3.find maximum results.                                         *
********************************************************************/
int MaxSubMatrixSum_Algorithm2(int a[maxSize][maxSize], int N)
{
    int i, j, m;
    int maxSum, thisSum;
    int b[maxSize];
    //initialize array
    for(i=0; i<N; i++){
        b[i] = 0;
    }
    //initialize maxSum
    maxSum = 0;

    //from row i to row m
    for(i=0; i<N; i++){
        for(m=i; m<N; m++){
            
			//b[j] = a[i][j] + a[i+1][j] + �� + a[m][j]
            for(j=0; j<N; j++){
                b[j] = b[j] + a[m][j];

                //if thisSum is bigger than maxSum, update maxSum
                if(thisSum > maxSum){
                    maxSum = thisSum;   
                }
            }
            //Find the largest sum of array b, which is the largest sum of submatrices from rows i to m
            thisSum = MaxSubSequenceSum(b, N);
        }
        //reset b[] = 0, preparing for next loops
        for(j=0; j<N; j++){
            b[j] = 0;
        }
    }

    return maxSum;
}

//this function mimics the textbook for solving the maximum subsequence sum of array
int MaxSubSequenceSum(int A[], int N)
{
    int thisSum, maxSum, i, j;

    thisSum = maxSum = 0;
    for(i=0; i<N; i++){
        thisSum = 0;
        for (j=i; j<N; j++){
            thisSum = thisSum + A[j];

            if (thisSum > maxSum){
                maxSum = thisSum;
            }
        }
    }

    /*for(i=0; i<N; i++){
        thisSum = thisSum + A[i];

        if(thisSum>maxSum){
            maxSum = thisSum;
        }else if(thisSum<0){
            thisSum = 0;
        }
    }*/

    return maxSum;
}
