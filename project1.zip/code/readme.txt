project1.cpp 是测试程序，输入N后，会生成随机的N*N数组，之后选择算法1or2，会给出ticks和duration，并在最后给出maxSum。
project1.exe_是可执行程序，请修改后缀后测试。